local tbl = 
{
	
	{
		
		{
			data = 
			{
				name = "Check Stance",
				uuid = "71a0e773-944a-cbfc-ae1b-cdae6ee1cd89",
				version = 2,
			},
			inheritedIndex = 14,
			inheritedObjectUUID = "b0f16fe2-c7e2-8901-8cda-04971b781ec6",
			inheritedOverwrites = 
			{
			},
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"397e521d-bc4d-9efa-9eef-27542478f095",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Hotbar_RoyalGuard",
							uuid = "3d884d79-7dc2-e280-a3e0-48ac80163222",
							variableTogglesType = 2,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							buffCheckType = 2,
							buffID = 1833,
							category = "Self",
							uuid = "397e521d-bc4d-9efa-9eef-27542478f095",
							version = 2,
						},
					},
				},
				mechanicTime = 13,
				name = "OT Stance On",
				timelineIndex = 1,
				timerOffset = -12,
				uuid = "3a238365-e289-c863-816c-5a97e85b8003",
				version = 2,
			},
			inheritedIndex = 28,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Hotbar_Potion",
							uuid = "088764a7-8d1d-aef3-8d15-4eb3ecc387ba",
							variableTogglesType = 2,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 13,
				name = "Force Potion",
				timelineIndex = 1,
				timerOffset = -9,
				uuid = "f1420274-a15c-4463-8cfa-46b95ffe330f",
				version = 2,
			},
			inheritedIndex = 31,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_LightningShot",
							uuid = "a5516c59-f440-e339-b91e-e4de755a0270",
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 13,
				name = "Lightning Shot On",
				timelineIndex = 1,
				timerOffset = -5,
				uuid = "9f92e4ae-a204-8f90-8324-ada8d0fc988e",
				version = 2,
			},
		},
	},
	
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 26.3,
				name = "HoS Self",
				timelineIndex = 2,
				timerOffset = -4,
				uuid = "d1b1a66e-d5d7-9054-82af-c6d650b35049",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraOT",
							uuid = "2499a85b-fd29-c334-9d33-2e02c65fb141",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 26.3,
				name = "Aurora Other",
				timelineIndex = 2,
				timerOffset = 2,
				uuid = "f2808ae6-0eb8-d23e-91f9-941215ae9ae4",
				version = 2,
			},
			inheritedIndex = 10,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Nebula",
							uuid = "38f47575-c29a-811b-b17b-7d656e8fdd2c",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 26.3,
				name = "Nebula",
				timelineIndex = 2,
				timerOffset = -15,
				uuid = "71c64fd8-b15d-b669-bc66-40d94193cbf5",
				version = 2,
			},
			inheritedIndex = 6,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				conditions = 
				{
				},
				mechanicTime = 26.3,
				name = "Aurora Self",
				timelineIndex = 2,
				timerEndOffset = 8,
				timerOffset = 1,
				timerStartOffset = 1,
				uuid = "387b735c-d361-d070-a2d4-c1ab0fe529ec",
				version = 2,
			},
			inheritedIndex = 11,
		},
	}, 
	[5] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 44.6,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 5,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -9,
				uuid = "82afb862-9bee-f383-b27b-23591d9b2f28",
				version = 2,
			},
			inheritedIndex = 18,
		},
	},
	[6] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 59.4,
				name = "HoS Self",
				timelineIndex = 6,
				timerOffset = -9,
				uuid = "995ad57d-8a94-d911-8434-4a9b9f62b251",
				version = 2,
			},
			inheritedIndex = 2,
		},
	},
	[9] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "2e6463c7-b109-854f-bee3-54f9917dd600",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 79.8,
				name = "Times Up HoL",
				timelineIndex = 9,
				timerOffset = -3,
				uuid = "7f86456d-10d2-6c30-ad2f-b9cf9bf67bf3",
				version = 2,
			},
			inheritedIndex = 2,
		},
	},
	[12] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 91.7,
				name = "HoS Self",
				timelineIndex = 12,
				timerOffset = -4,
				uuid = "cd65220a-ab8d-088c-a67d-15cfb326a2c6",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"0548823c-867f-ec45-8738-a5f3c2849ca1",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "3bdb859a-7735-8ec3-a4be-69c666cb6ad8",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							category = "Party",
							comparator = 2,
							conditionType = 4,
							inRangeValue = 15,
							minTargetPercent = true,
							partyTargetNumber = 100,
							partyTargetSubType = "Number",
							uuid = "0548823c-867f-ec45-8738-a5f3c2849ca1",
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				mechanicTime = 91.7,
				name = "Heart of Light Party Range Check",
				timeRange = true,
				timelineIndex = 12,
				timerEndOffset = -3,
				timerOffset = -15,
				timerStartOffset = -15,
				uuid = "66832b00-d578-f06d-a7ae-f7a8708ec26e",
				version = 2,
			},
			inheritedIndex = 16,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				conditions = 
				{
				},
				mechanicTime = 91.7,
				name = "Aurora Self",
				timelineIndex = 12,
				timerEndOffset = 8,
				timerOffset = 1,
				timerStartOffset = 1,
				uuid = "a939b345-8dcd-2d3c-9015-9ecd0995777c",
				version = 2,
			},
			inheritedIndex = 11,
		},
	},
	[13] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 102.5,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 13,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -9,
				uuid = "7cbab085-1514-6774-b1e3-cb354d40f80c",
				version = 2,
			},
			inheritedIndex = 18,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Camouflage",
							uuid = "8e2f4562-d752-2311-8dc3-5cf3202874b9",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 102.5,
				name = "Camo",
				timelineIndex = 13,
				timerOffset = -19,
				uuid = "25467001-3fa6-8a0a-a557-22787ad012d0",
				version = 2,
			},
			inheritedIndex = 7,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Rampart",
							uuid = "441831d0-2336-6312-8d84-3720f756f330",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 102.5,
				name = "Rampart",
				timelineIndex = 13,
				timerOffset = -19,
				uuid = "dce9b2ef-e3f5-c319-bdcd-42768946df6c",
				version = 2,
			},
			inheritedIndex = 8,
		},
	},
	[15] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 121.8,
				name = "HoS Self",
				timelineIndex = 15,
				timerOffset = -4,
				uuid = "ec853933-3b03-c7d4-a7f9-6bf54732dd20",
				version = 2,
			},
			inheritedIndex = 2,
		},
	},
	[17] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Jumps",
							gVarValue = 2,
							uuid = "af502369-cc27-e7a2-b7de-b609d95dae45",
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 121.9,
				name = "Jumps Off",
				timelineIndex = 17,
				timerOffset = -2,
				uuid = "469faecd-05c7-6571-ad50-cf2aab9bc748",
				version = 2,
			},
			inheritedIndex = 36,
		},
	},
	[20] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Jumps",
							uuid = "6e4e27e1-425c-0860-9718-bbd137e95c25",
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 132.9,
				name = "Jumps On",
				timelineIndex = 20,
				timerOffset = 1,
				uuid = "63abe84e-7cfc-808e-8c74-003b1cd664cf",
				version = 2,
			},
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Hotbar_Sprint",
							uuid = "bd53bff4-9a16-9c04-8bf9-f4e19a71d26e",
							variableTogglesType = 2,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 132.9,
				name = "Sprint",
				timelineIndex = 20,
				timerOffset = -10,
				uuid = "d236c7d5-3ef8-38a4-8f1b-b5173a6a56ff",
				version = 2,
			},
			inheritedIndex = 35,
		},
	},
	[22] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 157.1,
				name = "HoS Self",
				timelineIndex = 22,
				timerOffset = -4,
				uuid = "8a85cfbb-0614-67c8-b02a-b65be0547e8d",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				conditions = 
				{
				},
				mechanicTime = 157.1,
				name = "Aurora Self",
				timelineIndex = 22,
				timerEndOffset = 8,
				timerOffset = 1,
				timerStartOffset = 1,
				uuid = "5a01209b-74de-e40f-9004-fc4f559d3850",
				version = 2,
			},
			inheritedIndex = 11,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Nebula",
							uuid = "38f47575-c29a-811b-b17b-7d656e8fdd2c",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 157.1,
				name = "Nebula",
				timelineIndex = 22,
				timerOffset = -14,
				uuid = "8273239a-ac8f-6f0c-bcd3-eeaf1a5d1f90",
				version = 2,
			},
			inheritedIndex = 6,
		},
	},
	[26] = 
	{
		
		{
			data = 
			{
				name = "asd",
				uuid = "e3fe5bb7-463d-43b4-82d0-09cf6cb27b7c",
				version = 2,
			},
			inheritedObjectUUID = "fdb57e87-2340-f2a0-9583-6d42fb500d34",
			inheritedOverwrites = 
			{
				enabled = false,
				name = "asd",
			},
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Hotbar_ArmsLength",
							uuid = "01de4bcb-4e27-d8c5-9188-4c50168ff622",
							variableTogglesType = 2,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 182,
				name = "Knockback",
				timelineIndex = 26,
				timerOffset = -6,
				uuid = "d441e1cf-7ff7-707f-bf07-fb9a5a99db05",
				version = 2,
			},
		},
	},
	[27] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 185.8,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 27,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -9,
				uuid = "cceb0503-bb71-bfa8-a1a2-b1d33a72f9dd",
				version = 2,
			},
			inheritedIndex = 18,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 185.8,
				name = "HoS Self",
				timelineIndex = 27,
				timerOffset = -4,
				uuid = "e72b8f3c-f61d-aa41-b812-5b9661dfbfe1",
				version = 2,
			},
			inheritedIndex = 2,
		},
	},
	[33] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "2e6463c7-b109-854f-bee3-54f9917dd600",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 223.4,
				name = "Times Up HoL",
				timelineIndex = 33,
				timerOffset = -4,
				uuid = "a8e7e868-8a1c-a3c9-979a-fc7a0e2c6191",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 223.4,
				name = "HoS Self",
				timelineIndex = 33,
				timerOffset = -4,
				uuid = "1998b0fa-b05f-e2d8-baa5-1cf1748b757c",
				version = 2,
			},
			inheritedIndex = 3,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"0548823c-867f-ec45-8738-a5f3c2849ca1",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "3bdb859a-7735-8ec3-a4be-69c666cb6ad8",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							category = "Party",
							comparator = 2,
							conditionType = 4,
							inRangeValue = 15,
							minTargetPercent = true,
							partyTargetNumber = 100,
							partyTargetSubType = "Number",
							uuid = "0548823c-867f-ec45-8738-a5f3c2849ca1",
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				mechanicTime = 223.4,
				name = "Heart of Light Party Range Check",
				timeRange = true,
				timelineIndex = 33,
				timerEndOffset = -3,
				timerOffset = -15,
				timerStartOffset = -14,
				uuid = "d92634f6-f6f0-5ac2-9ef5-b221ca569762",
				version = 2,
			},
			inheritedIndex = 16,
		},
	},
	[36] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 258.3,
				name = "HoS Self",
				timelineIndex = 36,
				timerOffset = -4,
				uuid = "f2696d2d-9809-7475-870a-d94efacca573",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Camouflage",
							uuid = "8e2f4562-d752-2311-8dc3-5cf3202874b9",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 258.3,
				name = "Camo",
				timelineIndex = 36,
				timerOffset = -8,
				uuid = "e1757398-a8a9-4297-ba7d-e3a68c75e315",
				version = 2,
			},
			inheritedIndex = 7,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Rampart",
							uuid = "441831d0-2336-6312-8d84-3720f756f330",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 258.3,
				name = "Rampart",
				timelineIndex = 36,
				timerOffset = -8,
				uuid = "56f2386d-998c-8949-ae61-d28593ca552f",
				version = 2,
			},
			inheritedIndex = 8,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				conditions = 
				{
				},
				mechanicTime = 258.3,
				name = "Aurora Self",
				timelineIndex = 36,
				timerEndOffset = 8,
				timerOffset = 1,
				timerStartOffset = 1,
				uuid = "a35a50e2-d237-9e37-8305-f7f6ae39be2c",
				version = 2,
			},
			inheritedIndex = 11,
		},
	},
	[39] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 286.7,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 39,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -9,
				uuid = "1a2e9cca-9306-eb45-be24-612596be37e8",
				version = 2,
			},
			inheritedIndex = 18,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 286.7,
				name = "HoS Self",
				timelineIndex = 39,
				timerOffset = -4,
				uuid = "6aaf48b1-4344-e433-a141-eac88f24eda9",
				version = 2,
			},
			inheritedIndex = 2,
		},
	},
	[41] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Hotbar_Sprint",
							uuid = "bd53bff4-9a16-9c04-8bf9-f4e19a71d26e",
							variableTogglesType = 2,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 286.7,
				name = "Sprint",
				timelineIndex = 41,
				timerOffset = -10,
				uuid = "c07cac4a-5f67-dc81-b22f-844e9449c2dd",
				version = 2,
			},
			inheritedIndex = 35,
		},
	},
	[46] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"0548823c-867f-ec45-8738-a5f3c2849ca1",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "3bdb859a-7735-8ec3-a4be-69c666cb6ad8",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							category = "Party",
							comparator = 2,
							conditionType = 4,
							inRangeValue = 15,
							minTargetPercent = true,
							partyTargetNumber = 100,
							partyTargetSubType = "Number",
							uuid = "0548823c-867f-ec45-8738-a5f3c2849ca1",
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				mechanicTime = 309.7,
				name = "Heart of Light Party Range Check",
				timeRange = true,
				timelineIndex = 46,
				timerEndOffset = -3,
				timerOffset = -15,
				timerStartOffset = -15,
				uuid = "69b0e8ea-c3d1-83cd-90fa-a451358fe856",
				version = 2,
			},
			inheritedIndex = 16,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "2e6463c7-b109-854f-bee3-54f9917dd600",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 309.7,
				name = "Times Up HoL",
				timelineIndex = 46,
				timerOffset = -3,
				uuid = "35f0a53b-642f-d87f-b66d-7171dcc56f9d",
				version = 2,
			},
			inheritedIndex = 17,
		},
	},
	[47] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 324.2,
				name = "HoS Self",
				timelineIndex = 47,
				timerOffset = -4,
				uuid = "ebc006e2-056a-bf5e-9d61-1085519ea3dc",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 324.2,
				name = "Aurora Self",
				timeRange = true,
				timelineIndex = 47,
				timerEndOffset = 8,
				timerOffset = 0.5,
				timerStartOffset = 1,
				uuid = "2fe69c1e-899a-05e8-9063-adaaf07105b6",
				version = 2,
			},
			inheritedIndex = 4,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraOT",
							uuid = "2499a85b-fd29-c334-9d33-2e02c65fb141",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 324.2,
				name = "Aurora Other",
				timeRange = true,
				timelineIndex = 47,
				timerEndOffset = 8,
				timerOffset = 2,
				timerStartOffset = 2,
				uuid = "05299d93-cf66-d0a3-b37b-1c9af17401a8",
				version = 2,
			},
			inheritedIndex = 10,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Nebula",
							uuid = "38f47575-c29a-811b-b17b-7d656e8fdd2c",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 324.2,
				name = "Nebula",
				timelineIndex = 47,
				timerOffset = -14,
				uuid = "ffc3fd96-4b39-19aa-897b-e72c3adc48fd",
				version = 2,
			},
			inheritedIndex = 6,
		},
	},
	[51] = 
	{
		
		{
			data = 
			{
				name = "asd",
				uuid = "f2c72405-d7ce-726f-8dae-94bcaf37b7be",
				version = 2,
			},
			inheritedObjectUUID = "7a52b3ff-c74b-846b-b398-4f19caba062b",
			inheritedOverwrites = 
			{
				enabled = false,
				name = "asd",
			},
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 354.2,
				name = "HoS Self",
				timelineIndex = 51,
				timerOffset = -4,
				uuid = "bbc16d0a-0bc8-8079-87f0-a35186bf3604",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Hotbar_ArmsLength",
							uuid = "01de4bcb-4e27-d8c5-9188-4c50168ff622",
							variableTogglesType = 2,
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				conditions = 
				{
				},
				mechanicTime = 354.2,
				name = "Knockback",
				timelineIndex = 51,
				timerOffset = -6,
				uuid = "af3ec9c2-e4fd-462f-8085-2f53d7d892d6",
				version = 2,
			},
		},
	},
	[52] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 363.3,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 52,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -10,
				uuid = "dcf38af1-306b-2689-80c7-d7ddf2110782",
				version = 2,
			},
			inheritedIndex = 18,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Camouflage",
							uuid = "8e2f4562-d752-2311-8dc3-5cf3202874b9",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 363.3,
				name = "Camo",
				timelineIndex = 52,
				timerOffset = -19,
				uuid = "d7a00a66-ecdc-69f1-818d-73e36f6e21f0",
				version = 2,
			},
			inheritedIndex = 7,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Rampart",
							uuid = "441831d0-2336-6312-8d84-3720f756f330",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 363.3,
				name = "Rampart",
				timelineIndex = 52,
				timerOffset = -19,
				uuid = "3712de83-0886-b03d-8600-8de1e3605eba",
				version = 2,
			},
			inheritedIndex = 8,
		},
	},
	[58] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 407.5,
				name = "HoS Self",
				timelineIndex = 58,
				timerOffset = -8,
				uuid = "df58148f-0569-e544-ae45-2c9decc36cf8",
				version = 2,
			},
			inheritedIndex = 2,
		},
	},
	[59] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 407.9,
				name = "Aurora Self",
				timeRange = true,
				timelineIndex = 59,
				timerEndOffset = 8,
				timerOffset = 0.5,
				timerStartOffset = 1,
				uuid = "613cec25-5e41-edbb-b970-a0434e4a1f2d",
				version = 2,
			},
			inheritedIndex = 11,
		},
	},
	[64] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumMouse",
							targetSubType = "Lowest HP",
							targetType = "Party",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableIsHover = true,
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 429.7,
				name = "HoS Lowest",
				timelineIndex = 64,
				timerOffset = -4,
				uuid = "fbe53561-5375-0241-a888-662d74250468",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 429.7,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 64,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -10,
				uuid = "4400f261-4295-d88e-ba47-27980135cfab",
				version = 2,
			},
			inheritedIndex = 18,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"0548823c-867f-ec45-8738-a5f3c2849ca1",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "3bdb859a-7735-8ec3-a4be-69c666cb6ad8",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							category = "Party",
							comparator = 2,
							conditionType = 4,
							inRangeValue = 15,
							minTargetPercent = true,
							partyTargetNumber = 100,
							partyTargetSubType = "Number",
							uuid = "0548823c-867f-ec45-8738-a5f3c2849ca1",
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				mechanicTime = 429.7,
				name = "Heart of Light Party Range Check",
				timeRange = true,
				timelineIndex = 64,
				timerEndOffset = -3,
				timerOffset = -15,
				timerStartOffset = -14,
				uuid = "4bf1cb02-9124-9466-b356-451a1b32df61",
				version = 2,
			},
			inheritedIndex = 16,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "2e6463c7-b109-854f-bee3-54f9917dd600",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 429.7,
				name = "Times Up HoL",
				timelineIndex = 64,
				timerOffset = -3,
				uuid = "5d0773b8-5c12-3a58-9edc-b438090f6d9b",
				version = 2,
			},
			inheritedIndex = 17,
		},
	},
	[75] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumMouse",
							targetSubType = "Lowest HP",
							targetType = "Party",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableIsHover = true,
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 460.8,
				name = "HoS Lowest",
				timelineIndex = 75,
				timerOffset = -4,
				uuid = "d67300a9-b935-1cba-9b43-baa43656188c",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Nebula",
							uuid = "38f47575-c29a-811b-b17b-7d656e8fdd2c",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 460.8,
				name = "Nebula",
				timelineIndex = 75,
				timerOffset = -14,
				uuid = "551e679d-f006-5b12-822e-c756089a31fc",
				version = 2,
			},
			inheritedIndex = 6,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 460.8,
				name = "Aurora Self",
				timeRange = true,
				timelineIndex = 75,
				timerEndOffset = 8,
				timerOffset = 0.5,
				timerStartOffset = 1,
				uuid = "079fecbe-f505-7fc4-b736-6e0f822b0c73",
				version = 2,
			},
			inheritedIndex = 11,
		},
	},
	[80] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 486.4,
				name = "HoS Self",
				timelineIndex = 80,
				timerOffset = -4,
				uuid = "ab03b353-fdf2-a2c4-b40e-30506c564ec1",
				version = 2,
			},
			inheritedIndex = 2,
		},
	},
	[88] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 528.9,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 88,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -9,
				uuid = "20644a1e-b368-cdd4-8ca3-60257c3b9170",
				version = 2,
			},
			inheritedIndex = 18,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 528.9,
				name = "HoS Self",
				timelineIndex = 88,
				timerOffset = -4,
				uuid = "591913ed-5869-dfbc-853c-7fb20a54e5aa",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Camouflage",
							uuid = "8e2f4562-d752-2311-8dc3-5cf3202874b9",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 528.9,
				name = "Camo",
				timelineIndex = 88,
				timerOffset = -19,
				uuid = "77c5ac89-e9c9-76df-98a0-445012263de0",
				version = 2,
			},
			inheritedIndex = 7,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Rampart",
							uuid = "441831d0-2336-6312-8d84-3720f756f330",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 528.9,
				name = "Rampart",
				timelineIndex = 88,
				timerOffset = -19,
				uuid = "e9e883fc-2f9c-4c11-a60a-a19756fd4c5f",
				version = 2,
			},
			inheritedIndex = 8,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Hotbar_Sprint",
							uuid = "bd53bff4-9a16-9c04-8bf9-f4e19a71d26e",
							variableTogglesType = 2,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 528.9,
				name = "Sprint",
				timelineIndex = 88,
				timerOffset = -10,
				uuid = "8dc082fe-7696-7c87-9819-1fef0d659e12",
				version = 2,
			},
			inheritedIndex = 35,
		},
	},
	[91] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 561.3,
				name = "HoS Self",
				timelineIndex = 91,
				timerOffset = -10,
				uuid = "fc9cb644-6ff7-5012-bb90-04c24939b7e3",
				version = 2,
			},
			inheritedIndex = 3,
		},
	},
	[92] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Superbolide",
							uuid = "445f6157-11c9-67f8-98b8-a45d09df7c1a",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 561.6,
				name = "Superbolide",
				timelineIndex = 92,
				timerOffset = -7,
				uuid = "9a70b0ee-4822-20e1-b053-48071f0fd2ab",
				version = 2,
			},
			inheritedIndex = 9,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 561.6,
				name = "Aurora Self",
				timeRange = true,
				timelineIndex = 92,
				timerEndOffset = 8,
				timerOffset = 0.5,
				timerStartOffset = -6,
				uuid = "5b57b73d-ccd2-2360-bbd0-4b22e003b860",
				version = 2,
			},
			inheritedIndex = 11,
		},
	},
	[95] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 594,
				name = "HoS Self",
				timelineIndex = 95,
				timerOffset = -4,
				uuid = "57ee8aff-84ba-17fe-a68a-6e0e828cfcbc",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Nebula",
							uuid = "38f47575-c29a-811b-b17b-7d656e8fdd2c",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 594,
				name = "Nebula",
				timelineIndex = 95,
				timerOffset = -14,
				uuid = "10dd2bfe-f696-ba9d-83b0-860253ca2bb1",
				version = 2,
			},
			inheritedIndex = 3,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 594,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 95,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -9,
				uuid = "cd31f328-863e-bc8f-9233-642ec269fa49",
				version = 2,
			},
			inheritedIndex = 18,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Hotbar_Sprint",
							uuid = "8bda0c0f-64b0-40f3-8eb2-e5a21dd1d380",
							variableTogglesType = 2,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 594,
				name = "Sprint",
				timelineIndex = 95,
				timerOffset = -10,
				uuid = "b1d862a3-d14a-9023-b080-4e3308fae983",
				version = 2,
			},
			inheritedIndex = 5,
		},
	},
	[96] = 
	{
		
		{
			data = 
			{
				name = "asd",
				uuid = "95f27184-bd0d-9355-b8e2-71370261d55c",
				version = 2,
			},
			inheritedObjectUUID = "2da8c2bb-232e-3c66-8347-3a096206bbc5",
			inheritedOverwrites = 
			{
				enabled = false,
				name = "asd",
			},
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Hotbar_ArmsLength",
							uuid = "01de4bcb-4e27-d8c5-9188-4c50168ff622",
							variableTogglesType = 2,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 594,
				name = "Knockback",
				timelineIndex = 96,
				timerOffset = -6,
				uuid = "9a20291b-e5fd-20ec-9f60-376cf5f3186d",
				version = 2,
			},
		},
	},
	[98] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"0548823c-867f-ec45-8738-a5f3c2849ca1",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "3bdb859a-7735-8ec3-a4be-69c666cb6ad8",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							category = "Party",
							comparator = 2,
							conditionType = 4,
							inRangeValue = 15,
							minTargetPercent = true,
							partyTargetNumber = 100,
							partyTargetSubType = "Number",
							uuid = "0548823c-867f-ec45-8738-a5f3c2849ca1",
							version = 2,
						},
						inheritedIndex = 1,
					},
				},
				mechanicTime = 607,
				name = "Heart of Light Party Range Check",
				timeRange = true,
				timelineIndex = 98,
				timerEndOffset = -3,
				timerOffset = -15,
				timerStartOffset = -14,
				uuid = "8a1f14c8-6cdb-b2eb-a559-e16d53f0262f",
				version = 2,
			},
			inheritedIndex = 16,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfLight",
							uuid = "2e6463c7-b109-854f-bee3-54f9917dd600",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 607,
				name = "Times Up HoL",
				timelineIndex = 98,
				timerOffset = -3,
				uuid = "784cfe46-f098-98cc-af07-80c70d6eb5c7",
				version = 2,
			},
			inheritedIndex = 17,
		},
	},
	[101] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 627.5,
				name = "HoS Self",
				timelineIndex = 101,
				timerOffset = -4,
				uuid = "5f55de9b-b595-4093-9d3d-200ba86e3134",
				version = 2,
			},
			inheritedIndex = 2,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_AuroraSelf",
							uuid = "612f7ccf-70e0-e4b4-8498-0cba9769a984",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 627.5,
				name = "Aurora Self",
				timeRange = true,
				timelineIndex = 101,
				timerEndOffset = 8,
				timerOffset = 0.5,
				timerStartOffset = 1,
				uuid = "1e71d73b-f9af-093f-b8a3-f3219208a81a",
				version = 2,
			},
			inheritedIndex = 11,
		},
	},
	[104] = 
	{
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_HeartOfCorundumSelf",
							uuid = "9fb2fe40-09ba-1b9a-9b65-bbad6441f8d0",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 656.3,
				name = "HoS Self",
				timelineIndex = 104,
				timerOffset = -4,
				uuid = "2b289af8-1d37-ac78-8323-e44052467f93",
				version = 2,
			},
			inheritedIndex = 4,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							conditions = 
							{
								
								{
									"1aebffb2-27a5-2f3d-bb76-dc26439ad507",
									true,
								},
							},
							gVar = "ACR_RikuGNB2_Tankbar_Reprisal",
							uuid = "a34b0504-7d17-fdf8-b9b3-e6c46402c8f7",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
					
					{
						data = 
						{
							comparator = 2,
							conditionType = 6,
							inRangeValue = 5,
							uuid = "1aebffb2-27a5-2f3d-bb76-dc26439ad507",
							version = 2,
						},
					},
				},
				mechanicTime = 656.3,
				name = "Reprisal",
				timeRange = true,
				timelineIndex = 104,
				timerEndOffset = -0.5,
				timerOffset = -9,
				timerStartOffset = -9,
				uuid = "4397905e-23bf-95e2-ac28-66906a2ca4ab",
				version = 2,
			},
			inheritedIndex = 18,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Camouflage",
							uuid = "8e2f4562-d752-2311-8dc3-5cf3202874b9",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 656.3,
				name = "Camo",
				timelineIndex = 104,
				timerOffset = -19,
				uuid = "5108096a-df91-b141-8d8c-74bd826f3d38",
				version = 2,
			},
			inheritedIndex = 7,
		},
		
		{
			data = 
			{
				actions = 
				{
					
					{
						data = 
						{
							aType = "Variable",
							gVar = "ACR_RikuGNB2_Tankbar_Rampart",
							uuid = "441831d0-2336-6312-8d84-3720f756f330",
							variableTogglesType = 3,
							version = 2,
						},
					},
				},
				conditions = 
				{
				},
				mechanicTime = 656.3,
				name = "Rampart",
				timelineIndex = 104,
				timerOffset = -19,
				uuid = "85596972-36d8-4763-82fa-a38b87ed23aa",
				version = 2,
			},
			inheritedIndex = 8,
		},
	},
	inheritedProfiles = 
	{
		"store\\anyone\\savage2\\p7s",
	},
	mapID = 1086,
	version = 2,
}



return tbl